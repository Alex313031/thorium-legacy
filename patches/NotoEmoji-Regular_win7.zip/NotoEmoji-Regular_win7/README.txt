This .zip contains the Noto Emoji True Type Font from Google, for proper emoji support on the Web. 

Unzip it, and drag n' drop the font file into the Fonts window after going to Control Panel > Fonts. 

If you already installed the Noto font stuff from Supermium, you shouldn't install this on top of it.

NOTE: This should only be used on 7 or above, not on XP/Vista.
