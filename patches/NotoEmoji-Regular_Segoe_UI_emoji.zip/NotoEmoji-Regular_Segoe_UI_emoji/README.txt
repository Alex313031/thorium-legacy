This .zip contains the Noto Emoji True Type Font from Google, for proper emoji support on the Web. 

Unzip it, and drag n' drop the font file into the Fonts window after going to Control Panel > Fonts.