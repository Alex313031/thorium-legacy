Compatible with:
  Thorium/Supermium  x86 running on:

     XP SP3,
     XP SP2,
     Win2003 SP2

  Also should work with:
     Vista
     Win7

To use:
  For XP/2003:
     rename "chrome-win7-xp-api-router.dll" --> progwrp.dll
  For Win7/Vista:
     rename "chrome-win7-xp-api-router-Vista.dll" --> progwrp.dll


  And Place "chrome-xpapi-adapter.dll" around it.

  For "GPU HW Acceleration for Rendering on XP" feature, place "D3DCompiler_XP.dll" in same directory
    you should run browser with switches:
       --use-angle=d3d9 --ignore-gpu-blocklist
    or enable this flags in "about://flags"  constantly


Visit:
  https://github.com/IDA-RE-things/Chrome-xp-api-adapter
  for updates

(c) 2024 https://github.com/IDA-RE-things
